import firebase from "firebase/app";
import "firebase/firestore";

var firebaseConfig = {
  apiKey: "AIzaSyAnuw0Wd7T2S03T5EHQVFJnct2P1uG6alg",
  authDomain: "mod7-19a13.firebaseapp.com",
  projectId: "mod7-19a13",
  storageBucket: "mod7-19a13.appspot.com",
  messagingSenderId: "67946314583",
  appId: "1:67946314583:web:95f3bcd79fd35fcb981c12",
};

firebase.initializeApp(firebaseConfig);
export default firebase;
